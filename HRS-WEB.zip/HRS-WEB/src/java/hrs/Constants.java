package hrs;

public class Constants {
	public static String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";


	private static String dbName= "LccCompu_Ranjit";
	public static String dbUrl = "jdbc:sqlserver://167.114.1.10\\"+dbName;
	public static String dbUser = "LccCompu_Ranjit";
	public static String dbPwd = "Ranjit@123";



}